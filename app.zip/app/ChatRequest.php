<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class ChatRequest extends Model
{
   protected $guarded=[];
}
