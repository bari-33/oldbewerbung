<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class DesignCategory extends Model
{
    //
}
