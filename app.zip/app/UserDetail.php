<?php

namespace App;

use Illuminate\Database\Eloquent\Model;

class UserDetail extends Model
{
    protected $guarded=[];
    function user()
    {
        return $this->belongsTo(User::class);

    }

     function getDeutchLanguageAttribute()
     {
         if($this->deutch=='1')
         {
             $deutch='Deutch';
         }
         else
         {
             $deutch='';
         }
         return $deutch;
     }

    function getEnglishLanguageAttribute()
    {
        if($this->english=='1')
        {
            $english='English';
        }
        else
        {
            $english='';
        }
        return $english;
    }

    function getSpanishLanguageAttribute()
    {
        if($this->spanish=='1')
        {
            $spanish='Spanish';
        }
        else
        {
            $spanish='';
        }
        return $spanish;
    }

    function getFrenchLanguageAttribute()
    {
        if($this->french=='1')
        {
            $french='French';
        }
        else
        {
            $french='';
        }
        return $french;
    }


    public function employeeproducts()
    {
        return $this->hasMany(EmployeeProduct::class);

    }
}
