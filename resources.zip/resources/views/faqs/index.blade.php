@extends('layouts.app')
@section('css')

    @endsection
@section('content')
<div class="row">
    <div class="col-12">
        <div class="page-title-box">
           {{-- <div class="page-title-right">
                <form class="form-inline">
                    <div class="form-group">
                        <div class="input-group input-group-sm">
                            <input type="text" class="form-control shadow border-white" id="dash-daterange">
                            <div class="input-group-append">
                                                        <span class="input-group-text bg-primary border-primary text-white">
                                                            <i class="mdi mdi-calendar-range font-13"></i>
                                                        </span>
                            </div>
                        </div>
                    </div>
                    <a href="javascript: void(0);" class="btn btn-primary btn-sm ml-2 font-14">
                        <i class="mdi mdi-autorenew"></i>
                    </a>
                    <a href="javascript: void(0);" class="btn btn-primary btn-sm ml-1 font-14">
                        <i class="mdi mdi-filter-variant"></i>
                    </a>
                </form>
            </div>--}}
            <h4 class="page-title">Frequently Asked Questions</h4>
        </div>
    </div>
</div>


<!-- end row -->



<!-- Table with panel -->

<div class="row">
    <div class="col-12">
        <!-- Portlet card -->
        <div class="card">
            <div class="card-body">
                <div class="card-widgets">
                    <a href="javascript: void(0);" data-toggle="reload"><i class="mdi mdi-refresh"></i></a>
                    <a data-toggle="collapse" href="#cardCollpase4" role="button" aria-expanded="false" aria-controls="cardCollpase4"><i class="mdi mdi-minus"></i></a>
                    <a href="javascript: void(0);" data-toggle="remove"><i class="mdi mdi-close"></i></a>
                </div>
                <h4 class="header-title mb-0">Faqs</h4>

                <div id="cardCollpase4" class="collapse pt-3 show">
                    <div class="table-responsive">
                        <table class="table table-centered table-borderless mb-0">
                            <thead class="thead-light">
                            <tr>
                                <th>id</th>
                                <th>User Name</th>
                                <th>User Email</th>
                                <th>Question</th>
                                <th>Replied</th>
                                <th>Public</th>
                                <th>Action</th>
                            </tr>
                            </thead>
                            <tbody>
                            @foreach($faqs as $faq)
                                <tr>
                                    <td>{{$faq->id}}</td>
                                    <td>{{$faq->name}}</td>
                                    <td>{{$faq->email}}</td>
                                    <td>
                                        {{$faq->question}}
                                    </td>
                                    <td>
                                        @if($faq->replied==0)
                                            No
                                            @else
                                        Yes
                                            @endif
                                    </td>
                                    <td>
                                        @if($faq->set_public==0)
                                            No
                                        @else
                                            Yes
                                        @endif
                                    </td>
                                    <td>
                                        <a href="{{url('faqs/'.$faq->id.'/edit')}}">Reply</a>
                                    </td>
                                </tr>
                            @endforeach
                            </tbody>
                        </table>
                    </div> <!-- .table-responsive -->
                </div> <!-- end collapse-->
            </div> <!-- end card-body-->
        </div> <!-- end card-->
    </div> <!-- end col-->


</div>





@endsection